/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 50617
Source Host           : localhost:3306
Source Database       : symbioz

Target Server Type    : MYSQL
Target Server Version : 50617
File Encoding         : 65001

Date: 2016-04-17 14:33:28
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for stats
-- ----------------------------
DROP TABLE IF EXISTS `stats`;
CREATE TABLE `stats` (
  `CharacterId` int(255) NOT NULL DEFAULT '888888',
  `LifePoints` int(255) DEFAULT NULL,
  `MaxEnergyPoints` int(255) DEFAULT NULL,
  `Initiative` int(11) DEFAULT NULL,
  `Prospecting` int(11) DEFAULT NULL,
  `ActionPoints` int(11) DEFAULT NULL,
  `MovementPoints` int(11) DEFAULT NULL,
  `ContextStrength` int(11) DEFAULT NULL,
  `ContextVitality` int(11) DEFAULT NULL,
  `ContextWisdom` int(11) DEFAULT NULL,
  `ContextChance` int(11) DEFAULT NULL,
  `ContextAgility` int(11) DEFAULT NULL,
  `ContextIntelligence` int(11) DEFAULT NULL,
  `_Range` int(11) DEFAULT NULL,
  `SummonableCreaturesBoost` int(11) DEFAULT NULL,
  `Reflect` int(11) DEFAULT NULL,
  `CriticalHit` int(11) DEFAULT NULL,
  `CriticalHitWeapon` int(11) DEFAULT NULL,
  `HealBonus` int(11) DEFAULT NULL,
  `AllDamagesBonus` int(11) DEFAULT NULL,
  `AllDamagesBonusPercent` int(11) DEFAULT NULL,
  `WeaponDamagesBonusPercent` int(11) DEFAULT NULL,
  `TrapBonus` int(11) DEFAULT NULL,
  `TrapBonusPercent` int(11) DEFAULT NULL,
  `GlyphBonusPercent` int(11) DEFAULT NULL,
  `PushDamageBonus` int(11) DEFAULT NULL,
  `CriticalDamageBonus` int(11) DEFAULT NULL,
  `NeutralDamageBonus` int(11) DEFAULT NULL,
  `EarthDamageBonus` int(11) DEFAULT NULL,
  `WaterDamageBonus` int(11) DEFAULT NULL,
  `AirDamageBonus` int(11) DEFAULT NULL,
  `FireDamageBonus` int(11) DEFAULT NULL,
  `DodgePA` int(11) DEFAULT NULL,
  `DodgePM` int(11) DEFAULT NULL,
  `NeutralResistPercent` int(11) DEFAULT NULL,
  `EarthResistPercent` int(11) DEFAULT NULL,
  `WaterResistPercent` int(11) DEFAULT NULL,
  `AirResistPercent` int(11) DEFAULT NULL,
  `FireResistPercent` int(11) DEFAULT NULL,
  `NeutralReduction` int(11) DEFAULT NULL,
  `EarthReduction` int(11) DEFAULT NULL,
  `WaterReduction` int(11) DEFAULT NULL,
  `AirReduction` int(11) DEFAULT NULL,
  `FireReduction` int(11) DEFAULT NULL,
  `PushDamageReduction` int(11) DEFAULT NULL,
  `CriticalDamageReduction` int(11) DEFAULT NULL,
  `PvPNeutralResistPercent` int(11) DEFAULT NULL,
  `PvPEarthResistPercent` int(11) DEFAULT NULL,
  `PvPWaterResistPercent` int(11) DEFAULT NULL,
  `PvPAirResistPercent` int(11) DEFAULT NULL,
  `PvPFireResistPercent` int(11) DEFAULT NULL,
  `PvPNeutralReduction` int(11) DEFAULT NULL,
  `PvPEarthReduction` int(11) DEFAULT NULL,
  `PvPWaterReduction` int(11) DEFAULT NULL,
  `PvPAirReduction` int(11) DEFAULT NULL,
  `PvPFireReduction` int(255) DEFAULT NULL,
  `GlobalDamageReduction` int(255) DEFAULT NULL,
  `BaseStrength` int(11) DEFAULT NULL,
  `BaseAgility` int(11) DEFAULT NULL,
  `BaseChance` int(11) DEFAULT NULL,
  `BaseVitality` int(11) DEFAULT NULL,
  `BaseWisdom` int(11) DEFAULT NULL,
  `BaseIntelligence` int(11) DEFAULT NULL,
  `PermanentStrenght` int(11) DEFAULT NULL,
  `PermanentAgility` int(11) DEFAULT NULL,
  `PermanentChance` int(11) DEFAULT NULL,
  `PermanentVitality` int(11) DEFAULT NULL,
  `PermanentWisdom` int(11) DEFAULT NULL,
  `PermanentIntelligence` int(11) DEFAULT NULL,
  `ContextAPReduction` int(11) DEFAULT NULL,
  PRIMARY KEY (`CharacterId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
