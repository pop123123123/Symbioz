/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 50617
Source Host           : localhost:3306
Source Database       : symbioz

Target Server Type    : MYSQL
Target Server Version : 50617
File Encoding         : 65001

Date: 2016-10-24 18:03:33
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for mapstriggers
-- ----------------------------
DROP TABLE IF EXISTS `mapstriggers`;
CREATE TABLE `mapstriggers` (
  `Id` int(11) NOT NULL,
  `MapId` int(11) DEFAULT NULL,
  `CellId` int(11) DEFAULT NULL,
  `TriggerType` int(11) DEFAULT NULL,
  `TargetMapId` int(11) DEFAULT NULL,
  `TargetCellId` int(11) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of mapstriggers
-- ----------------------------
INSERT INTO `mapstriggers` VALUES ('1', '54534165', '424', '1', '54172457', '372');
INSERT INTO `mapstriggers` VALUES ('2', '54534165', '409', '1', '54172457', '372');
