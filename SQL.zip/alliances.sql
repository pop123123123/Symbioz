/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 50617
Source Host           : localhost:3306
Source Database       : symbioz

Target Server Type    : MYSQL
Target Server Version : 50617
File Encoding         : 65001

Date: 2016-10-24 06:00:08
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for alliances
-- ----------------------------
DROP TABLE IF EXISTS `alliances`;
CREATE TABLE `alliances` (
  `Id` int(11) NOT NULL,
  `Name` varchar(255) DEFAULT NULL,
  `Tag` varchar(255) DEFAULT NULL,
  `SymbolColor` int(11) DEFAULT NULL,
  `SymbolShape` int(11) DEFAULT NULL,
  `BackgroundShape` int(11) DEFAULT NULL,
  `BackgroundColor` int(11) DEFAULT NULL,
  `LeaderGuildId` int(11) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of alliances
-- ----------------------------

-- ----------------------------
-- Table structure for guildsalliances
-- ----------------------------
DROP TABLE IF EXISTS `guildsalliances`;
CREATE TABLE `guildsalliances` (
  `GuildId` int(11) NOT NULL,
  `AllianceId` int(11) DEFAULT NULL,
  PRIMARY KEY (`GuildId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of guildsalliances
-- ----------------------------
